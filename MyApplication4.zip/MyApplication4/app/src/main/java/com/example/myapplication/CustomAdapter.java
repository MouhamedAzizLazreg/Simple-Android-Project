package com.example.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList<String> food_id, food_name, food_description, food_price;

    CustomAdapter(Activity activity, Context context, ArrayList<String> food_id, ArrayList<String> food_name,
                  ArrayList<String> food_description, ArrayList<String> food_price) {
        this.activity = activity;
        this.context = context;
        this.food_id = food_id;
        this.food_name = food_name;
        this.food_description = food_description;
        this.food_price = food_price;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.fooddetailactivity, parent, false);
        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        holder.foodNameTextView.setText(food_name.get(position));
        holder.descriptionTextView.setText(food_description.get(position));
        holder.priceTextView.setText(food_price.get(position));

        // RecyclerView onClickListener
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the click event
                // You can open a new activity or perform any other action
                // based on the selected item
                String selectedFoodId = food_id.get(position);
                String selectedFoodName = food_name.get(position);
                String selectedFoodDescription = food_description.get(position);
                String selectedFoodPrice = food_price.get(position);

                // Example: Opening a detail activity for the selected food
                Intent intent = new Intent(context, FoodDetailActivity.class);
                intent.putExtra("id", selectedFoodId);
                intent.putExtra("foodName", selectedFoodName);
                intent.putExtra("foodDescription", selectedFoodDescription);
                intent.putExtra("foodPrice", selectedFoodPrice);
                activity.startActivity(intent);
            }

        });
    }

    @Override
    public int getItemCount() {
        return food_name.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView foodNameTextView, descriptionTextView, priceTextView;
        LinearLayout mainLayout;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            foodNameTextView = itemView.findViewById(R.id.food_name_txt);
            descriptionTextView = itemView.findViewById(R.id.food_description_txt);
            priceTextView = itemView.findViewById(R.id.food_price_txt);
            mainLayout = itemView.findViewById(R.id.mainLayout);
        }
    }
}