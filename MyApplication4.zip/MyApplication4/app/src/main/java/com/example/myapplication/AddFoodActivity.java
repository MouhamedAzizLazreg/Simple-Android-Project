package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddFoodActivity extends AppCompatActivity {

    EditText nameInput, descriptionInput, priceInput;
    Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_food);

        nameInput = findViewById(R.id.name_input);
        descriptionInput = findViewById(R.id.description_input);
        priceInput = findViewById(R.id.price_input);
        addButton = findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddFoodActivity.this);
                myDB.addFood(nameInput.getText().toString().trim(),
                        descriptionInput.getText().toString().trim(),
                        priceInput.getText().toString().trim());
            }
        });
    }
}