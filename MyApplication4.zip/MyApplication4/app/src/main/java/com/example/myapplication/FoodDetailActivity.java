package com.example.myapplication;


import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FoodDetailActivity extends AppCompatActivity {

    EditText foodNameInput, foodDescriptionInput, foodPriceInput;
    Button updateButton, deleteButton;

    String id, foodName, foodDescription, foodPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_detail_activity);

        foodNameInput = findViewById(R.id.food_name_txt);
        foodDescriptionInput = findViewById(R.id.food_description_txt);
        foodPriceInput = findViewById(R.id.food_price_txt);
        updateButton = findViewById(R.id.update_button);
        deleteButton = findViewById(R.id.delete_button);

        // First we call this
        getAndSetIntentData();

        // Set actionbar title after getAndSetIntentData method
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(foodName);
        }

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // And only then we call this
                MyDatabaseHelper myDB = new MyDatabaseHelper(FoodDetailActivity.this);
                foodName = foodNameInput.getText().toString().trim();
                foodDescription = foodDescriptionInput.getText().toString().trim();
                foodPrice = foodPriceInput.getText().toString().trim();
                myDB.updateData(id, foodName, foodDescription, foodPrice);
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog();
            }
        });
    }

    void getAndSetIntentData() {
        if (getIntent().hasExtra("id") && getIntent().hasExtra("foodName") &&
                getIntent().hasExtra("foodDescription") && getIntent().hasExtra("foodPrice")) {
            // Getting Data from Intent
            id = getIntent().getStringExtra("id");
            foodName = getIntent().getStringExtra("foodName");
            foodDescription = getIntent().getStringExtra("foodDescription");
            foodPrice = getIntent().getStringExtra("foodPrice");

            // Setting Intent Data
            foodNameInput.setText(foodName);
            foodDescriptionInput.setText(foodDescription);
            foodPriceInput.setText(foodPrice);
            Log.d("stev", foodName + " " + foodDescription + " " + foodPrice);
        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    void confirmDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + foodName + " ?");
        builder.setMessage("Are you sure you want to delete " + foodName + " ?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(FoodDetailActivity.this);
                myDB.deleteOneRow(id);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }
}